# Boost.Python

This directory contains the sources for Boost.Python library, extracted from
the 1.60 Boost distribution.
